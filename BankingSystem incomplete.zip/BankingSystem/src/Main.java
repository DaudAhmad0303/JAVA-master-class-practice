import java.util.Scanner;


public class Main {
static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        Bank bank = new Bank(100);
        addDummyAccounts(bank);
//        ICsvBeanWriter beanWriter = null;


        int choice;
        do {
            mainMenu();
            choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Account Title: ");
                    String accountTitle = scanner.nextLine();
                    AccountType accountType = Bank.getAccountTypeWithInput();
                    System.out.print("Enter opening Balance: ");
                    double balance = Double.parseDouble(scanner.nextLine());
                    String accountNo = bank.addAccount(accountTitle, accountType, balance);
                    System.out.println("Account created successfully...\n Your Account Details:");
                    bank.listAccountDetails(accountNo);
                }
                case 2 -> {
                    System.out.print("Enter your account No: ");
                    String accountNo = scanner.nextLine();
                    bank.updateAccount(accountNo);
                }
                case 3 -> {
                    System.out.print("Enter your account No: ");
                    String accountNo = scanner.nextLine();
                    if (bank.deleteAccount(accountNo)) {
                        System.out.println("Your account deleted Successfully!");
                    } else {
                        System.out.println("Account Number does not found!!!");
                    }
                }
                case 4 -> {
                    System.out.print("Enter your account No: ");
                    String accountNo = scanner.nextLine();
                    bank.listAccountDetails(accountNo);
                }
                case 5 -> {
                    System.out.print("Enter your account No: ");
                    String accountNo = scanner.nextLine();
                    System.out.print("Enter amount to withdraw: ");
                    double amount = Double.parseDouble(scanner.nextLine());
                    bank.withdrawAmount(accountNo, amount);
                    System.out.println("Amount withdrawal Successfully...");
                }
                case 6 -> {
                    System.out.print("Enter your account No: ");
                    String accountNo = scanner.nextLine();
                    System.out.print("Enter amount to deposit: ");
                    double amount = Double.parseDouble(scanner.nextLine());
                    bank.depositAmount(accountNo, amount);
                    System.out.println("Amount deposited Successfully...");
                }
                case 7 -> {
                    bank.listAllAccountsDetails();
                }
                case 0 -> {
                    break;
                }
                default -> {
                    System.out.print("Invalid choice");
                }
            }
        } while (choice != 0);
    }

    public static void mainMenu() {
        System.out.print("""
                
                1. Add Account
                2. Update Account
                3. Delete Account
                4. List a single Account
                5. With Draw money
                6. Deposit money
                7. List All Accounts
                0. Exit
                Enter your choice: """);
    }

    public static void addDummyAccounts(Bank bank) {

        var allAccounts = AccountType.values();

        bank.addAccount("Daud Ahmad", allAccounts[0], 100);
        bank.addAccount("Sajid Tariq", allAccounts[1], 50);
        bank.addAccount("Abdullah", allAccounts[0], 1000);
        bank.addAccount("Ali Asad", allAccounts[2], 0);
        bank.addAccount("Usman Ali", allAccounts[1], 10_000);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Wasif Dar", allAccounts[0], 0);
        bank.addAccount("Salman Yousuf", allAccounts[0], 500);
    }

//    public CsvPreference customCsvPreference(){
//        return new CsvPreference.Builder('|', ',', "\n").build();
//    }
}
